//
//  SGDL2Utils.h
//  sgsdl2
//
//  Created by Andrew Cain on 20/11/2013.
//  Copyright (c) 2013 Andrew Cain. All rights reserved.
//

#ifndef sgsdl2_SGSDL2Utils_h
#define sgsdl2_SGSDL2Utils_h

#include <iostream>
#include "sgInterfaces.h"


void sgsdl2_load_util_fns(sg_interface *functions);



#endif /* defined(__sgsdl2__SGDL2Utils__) */
