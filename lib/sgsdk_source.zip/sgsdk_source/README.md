# Linux Setup Details
While this project should work on Mac and Windows without special attention,
you need to install the native libraries on Linux.

1. cd sgsdl
2. ./build.sh -i

Enter sudo password when required to install native libraries and related
header files.
